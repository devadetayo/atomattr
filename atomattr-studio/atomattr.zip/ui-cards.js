/* AtomAttr UI — shared component cards (UIverse-style).
   One card design used by the UI page, the catalog gallery and the Studio, so every surface matches.
   Data comes from loadItems(): published components plus (for the owner) Studio drafts. */
import { esc, KIND, frameOf, previewDocument, loadItems } from './ui-lib.js';

const SAVED_KEY = 'atomattr-ui-saved';
const TOP = ['Navbars', 'Sections', 'Templates'];
const readSaved = () => { try { return new Set(JSON.parse(localStorage.getItem(SAVED_KEY) || '[]')); } catch { return new Set(); } };
const writeSaved = (set) => { try { localStorage.setItem(SAVED_KEY, JSON.stringify([...set])); } catch { /* storage unavailable */ } };
const initials = (name = '') => name.split(/\s+/).filter(Boolean).slice(0, 2).map((w) => w[0]).join('').toUpperCase() || 'A';

export function componentCard(item, saved = readSaved()) {
  const href = `./item.html?slug=${encodeURIComponent(item.slug)}`;
  const on = saved.has(item.slug);
  const draft = item.origin === 'draft';
  const f = frameOf(item);
  const wide = TOP.includes(item.category);
  return `<article data-card="${esc(item.slug)}" data-reveal group display="flex" flex-col gap="3">
  <div data-stage data-wide="${wide ? 1 : 0}" data-fw="${f.w}" data-fh="${f.h}" position="relative" overflow="hidden" rounded="2xl" bg="#f1f1f4" dark-bg="#17181b" border="1px solid #0000/5" dark-border-color="#ffffff/10" h="72" group-hover-shadow="xl" transition="all" duration="300ms">
    <a href="${href}" aria-label="Open ${esc(item.name)}" position="absolute" top="0" left="0" w="full" h="full" z="1"></a>
    <iframe title="${esc(item.name)} preview" loading="lazy" tabindex="-1" aria-hidden="true" data-slug="${esc(item.slug)}" border="0" pointer-events="none" bg="transparent" style="position:absolute;left:0;top:0;width:100%;height:100%;transform-origin:0 0"></iframe>
    ${draft ? '<span position="absolute" top="3" left="3" z="2" bg="warning/15" text="warning" rounded="full" px="2.5" py="0.5" font-size="xs" font-weight="700">Draft</span>' : ''}
    <a href="${href}" position="absolute" bottom="3" right="3" z="2" display="inline-flex" items="center" gap="1.5" px="3" py="1.5" rounded="lg" bg="#fff/0" hover-bg="#fff" dark-hover-bg="#ffffff/10" text="text" font-size="sm" font-weight="700" text-decoration="none" transition="all" duration="200ms" style="backdrop-filter:blur(6px)"><i class="ri-code-s-slash-line"></i> Get code</a>
  </div>
  <div display="flex" items="center" justify="between" gap="3" px="1">
    <div display="flex" items="center" gap="2.5" min-w="0">
      <span w="7" h="7" rounded="full" display="flex" items="center" justify="center" flex="none" font-size="xs" font-weight="700" text="white" bg-image="linear-gradient(135deg,#6366f1,#ec4899)">${esc(initials(item.creator))}</span>
      <div min-w="0"><p m="0" font-size="sm" font-weight="700" truncate>${esc(item.name)}</p><p m="0" font-size="xs" text="muted" truncate>${esc(item.creator || 'AtomAttr')} · ${esc(KIND[item.category] || item.category)}</p></div>
    </div>
    <button type="button" data-save="${esc(item.slug)}" aria-pressed="${on}" aria-label="Save ${esc(item.name)}" flex="none" display="flex" items="center" gap="1" bg="transparent" border="0" text="${on ? 'primary' : 'muted'}" hover-text="primary" font-size="lg" cursor="pointer"><i class="${on ? 'ri-bookmark-fill' : 'ri-bookmark-line'}"></i></button>
  </div>
</article>`;
}

function fit(stage) {
  const ifr = stage.querySelector('iframe'); if (!ifr) return;
  const cw = stage.clientWidth, ch = stage.clientHeight;
  if (stage.dataset.wide === '1') {
    const fw = +stage.dataset.fw, fh = +stage.dataset.fh;
    const k = cw / fw;
    ifr.style.width = fw + 'px'; ifr.style.height = fh + 'px';
    ifr.style.transform = `scale(${k})`;
    stage.style.height = Math.min(Math.max(fh * k, 200), 288) + 'px';
    return;
  }
  /* Small components render at natural size, and shrink only when they would not fit above the Get code row. */
  let k = 1;
  try {
    const kids = [...ifr.contentDocument.body.children].filter((n) => n.tagName !== 'SCRIPT');
    if (kids.length) {
      const r = kids.map((n) => n.getBoundingClientRect());
      const natural = Math.max(...r.map((x) => x.bottom)) - Math.min(...r.map((x) => x.top));
      const room = (ch - 72) * (ifr._k || 1);
      if (natural > room) k = Math.max(0.45, room / natural);
    }
  } catch { /* cross-origin or not loaded yet */ }
  ifr._k = k;
  ifr.style.width = cw / k + 'px'; ifr.style.height = ch / k + 'px';
  ifr.style.transform = k === 1 ? 'none' : `scale(${k})`;
}

export function paint(root, byslug) {
  root.querySelectorAll('iframe[data-slug]').forEach((f) => {
    const item = byslug.get(f.dataset.slug);
    if (item) { f.onload = () => setTimeout(() => fit(f.closest('[data-stage]')), 60); f.srcdoc = previewDocument(item, { transparent: true, padBottom: 56 }); }
  });
  root.querySelectorAll('[data-stage]').forEach(fit);
}

/* Bookmark clicks, theme changes and resizes for any grid of cards (used by mountCards and the Studio library). */
export function bindCards(grid) {
  if (grid._aaBound) return;
  grid._aaBound = true;
  grid.addEventListener('click', (e) => {
    const b = e.target.closest('[data-save]'); if (!b) return;
    const set = readSaved(), s = b.dataset.save, on = !set.has(s);
    on ? set.add(s) : set.delete(s); writeSaved(set);
    b.setAttribute('aria-pressed', on); b.setAttribute('text', on ? 'primary' : 'muted');
    b.firstElementChild.className = on ? 'ri-bookmark-fill' : 'ri-bookmark-line';
  });
  new MutationObserver(() => paint(grid, grid._aaMap || new Map())).observe(document.documentElement, { attributes: true, attributeFilter: ['class'] });
  new ResizeObserver(() => grid.querySelectorAll('[data-stage]').forEach(fit)).observe(grid);
}

/* Renders cards into `grid`, wires bookmarks, keeps previews in sync with theme + width. */
export function mountCards(grid, items) {
  const byslug = new Map(items.map((i) => [i.slug, i]));
  const saved = readSaved();
  grid.innerHTML = items.map((i) => componentCard(i, saved)).join('');
  paint(grid, byslug);
  bindCards(grid);
  grid._aaMap = byslug;
  if (window.__aaReveal) window.__aaReveal(grid);
}

export { loadItems };
